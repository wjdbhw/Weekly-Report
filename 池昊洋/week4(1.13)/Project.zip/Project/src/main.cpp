#define WIN32_LEAN_AND_MEAN
#include "graph.h"
#include "calculate.h"
#include <iostream>
#include <mysql.h>
#include "crow.h"
#include <string>
#include <map>
#include <mutex>
#include <memory>
#include <shared_mutex> 

using namespace std;
// 定义全局变量
UserGraph globalGraph;
std::map<int, std::shared_ptr<UserGraph>> userSessionGraphs; // 存储用户专属图
std::mutex sessionMutex; // 保护 map 的并发访问
std::shared_mutex globalGraphLock;

// 1. 定义全局跨域中间件
struct CORSMiddleware {
    struct context {};

    void before_handle(crow::request& req, crow::response& res, context& ctx) {
        // 动态获取 Origin，如果获取不到则用 *
        std::string origin = req.get_header_value("Origin");
        res.set_header("Access-Control-Allow-Origin", origin.empty() ? "*" : origin);
        
        // 必须允许这些方法
        res.set_header("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, OPTIONS");
        
        // 【关键修复】确保这三个 Header 拼写完全正确且在同一个字符串里
        res.set_header("Access-Control-Allow-Headers", "Content-Type, Authorization, ngrok-skip-browser-warning");
        
        // 允许携带 Cookie (针对 ngrok 环境建议加上)
        res.set_header("Access-Control-Allow-Credentials", "true");

        // 解决第一个 CSP 报错
        res.set_header("Content-Security-Policy", "default-src * 'unsafe-inline' 'unsafe-eval'; script-src * 'unsafe-inline' 'unsafe-eval';");

        // 如果是预检请求 OPTIONS，直接结束，不进入任何路由处理
        if (req.method == "OPTIONS"_method) {
            res.code = 204;
            res.end(); 
        }
    }

    void after_handle(crow::request& req, crow::response& res, context& ctx) {
        // 确保非 OPTIONS 请求也有跨域头
        if (res.get_header_value("Access-Control-Allow-Origin").empty()) {
            std::string origin = req.get_header_value("Origin");
            res.set_header("Access-Control-Allow-Origin", origin.empty() ? "*" : origin);
        }
    }
};

// 获取或创建用户专属图
UserGraph& getOrCreateUserGraph(int uid) {
    std::lock_guard<std::mutex> lock(sessionMutex);
    
    // 如果该用户 ID 还没有对应的图，则克隆全局图
    if (userSessionGraphs.find(uid) == userSessionGraphs.end()) {
        auto newGraph = std::make_shared<UserGraph>();
        newGraph->cloneFrom(globalGraph); // 从全局同步一份基础数据
        userSessionGraphs[uid] = newGraph;
        cout << "[Session] Created virtual graph for UserID: " << uid << endl;
    }
    return *userSessionGraphs[uid];
}

// ---------- MySQL 连接 ----------
MYSQL* GetConn() {
    MYSQL* conn = mysql_init(nullptr);
    if (!conn) return nullptr;
  
    if (!mysql_real_connect(
        conn,
        "localhost", // 主机
        "root",      // 用户
        "MySQL",     // 密码
        "traffic",   // 数据库
        3306,        // 端口
        nullptr,
        0
    )) {
        mysql_close(conn);
        return nullptr;
    }
    return conn;
}

// 模拟 Session
struct UserSession {
    int id;
    string username;
    string role;
};
std::map<string, UserSession> sessions; // Token -> Session
std::mutex sessionLock;

// 辅助函数：通过 Header 中的 Authorization 获取用户 ID
int getAuthId(const crow::request& req) {
    auto token = req.get_header_value("Authorization");
    std::lock_guard<std::mutex> lock(sessionLock);
    if (sessions.count(token)) return sessions[token].id;
    return -1;
}

// 辅助函数：检查是否为管理员
bool isAdmin(const crow::request& req) {
    // 1. 获取 Header 中的 Token
    string auth = req.get_header_value("Authorization");
    
    // 2. 这里的 sessionLock 必须和你登录时用的是同一个
    std::lock_guard<std::mutex> lock(sessionLock); 
    
    // 3. 检查 sessions Map
    if (sessions.count(auth)) {
        // 调试打印：看看内存里存的到底是啥
//         cout << "Current Role: " << sessions[auth].role << endl; 
        return sessions[auth].role == "admin"; // 必须全小写匹配
    }
    return false;
}
// 数据库同步算法
bool SyncFromDB() {
    std::unique_lock<std::shared_mutex> lock(globalGraphLock); // 写锁
    MYSQL* conn = GetConn();
    if (!conn) {
        cerr << "Sync Error: Database connection failed." << endl;
        return false;
    }

    // 空当前内存图
    globalGraph.clear();

    // 导入城市
    if (mysql_query(conn, "SELECT name, admin_id FROM Cities")) {
        cerr << "Sync Error (Cities): " << mysql_error(conn) << endl;
        mysql_close(conn);
        return false;
    }

    MYSQL_RES* cityRes = mysql_store_result(conn);
    MYSQL_ROW row;
    while ((row = mysql_fetch_row(cityRes))) {
        string cityName = row[0] ? row[0] : "";
        string adminId = row[1] ? row[1] : "";
        if (!cityName.empty()) {
            globalGraph.addCity(cityName, adminId);
        }
    }
    mysql_free_result(cityRes);

    // 导入边（交通路线）
    const char* edgeSql = "SELECT from_city, to_city, transport, depart_time, "
                          "arrive_time, cost, number, duration, status FROM arc_data";
    if (mysql_query(conn, edgeSql)) {
        cerr << "Sync Error (Edges): " << mysql_error(conn) << endl;
        mysql_close(conn);
        return false;
    }

    MYSQL_RES* edgeRes = mysql_store_result(conn);
    while ((row = mysql_fetch_row(edgeRes))) {
        string from = row[0];
        string to = row[1];
        
        // 查找城市索引
        int u = globalGraph.findCityIndex(from);
        int v = globalGraph.findCityIndex(to);

        // 只有当出发城市和到达城市都在城市库中时，才添加边
        if (u != -1 && v != -1) {
            globalGraph.addEdge(
                u, 
                v, 
                row[2],                 // transport
                row[3],                 // depart_time
                row[4],                 // arrive_time
                stoi(row[5]),           // cost
                row[6],                 // number
                stoi(row[7]),           // duration
                row[8] ? row[8] : "active" // status
            );
        }
    }
    mysql_free_result(edgeRes);
    
    mysql_close(conn);
    cout << "Success: globalGraph synchronized with database. (Cities: " 
         << globalGraph.cityCount << ")" << endl;
    return true;
}


// ---------- 主函数 ----------
int main() {
    // 2. 将中间件注册进 App
    crow::App<CORSMiddleware> app;
    // 1. 启动时先同步数据
    if(!SyncFromDB()) {
        cout << "Warning: Initial data sync failed!" << endl;
    }



    //-------登录与注册--------
    // [注册]
    CROW_ROUTE(app, "/api/auth/register").methods("POST"_method)
    ([](const crow::request& req) {
        auto body = crow::json::load(req.body);
        if (!body) return crow::response(400, "Invalid JSON");

        string user = body["username"] ? (string)body["username"].s() : "";
        string pass = body["password"] ? (string)body["password"].s() : "";

        if (user.empty() || pass.empty()) return crow::response(400, "Fields cannot be empty");

        string role = "user";
        
        if (body.has("admin_key")) {
            string provided_key = (string)body["admin_key"].s();
            // 如果提供了密钥但内容为空，或者内容不匹配
            if (provided_key.empty() || provided_key != "SUPER_SECRET_123") {
                return crow::response(403, "Invalid Admin Key"); // 403 拒绝访问
            }
            role = "admin";
        }

        MYSQL* conn = GetConn();
        string sql = "INSERT INTO Users (username, password, role) VALUES ('" + user + "', '" + pass + "', '" + role + "')";
        
        if (mysql_query(conn, sql.c_str())) {
            string err = mysql_error(conn);
            mysql_close(conn);
            if (err.find("Duplicate entry") != string::npos) return crow::response(409, "Username exists");
            return crow::response(500, err);
        }
        mysql_close(conn);
        return crow::response(200, "Registered");
    });

    // [登录]
    CROW_ROUTE(app, "/api/auth/login").methods("POST"_method)
    ([](const crow::request& req) {
        auto body = crow::json::load(req.body);
        string user = body["username"].s();
        string pass = body["password"].s();

        MYSQL* conn = GetConn();
        string sql = "SELECT user_id, role FROM Users WHERE username='" + user + "' AND password='" + pass + "'";
        mysql_query(conn, sql.c_str());
        MYSQL_RES* res = mysql_store_result(conn);
        MYSQL_ROW row = mysql_fetch_row(res);

        if (!row) {
            mysql_free_result(res); mysql_close(conn);
            return crow::response(401, "Login failed");
        }

        // --- Token 生成逻辑 ---
    
        // 1. 获取当前高精度时间戳（纳秒级），确保时间维度上的唯一性
        auto now = std::chrono::high_resolution_clock::now().time_since_epoch().count();
        
        // 2. 使用 C++11 的随机数生成器（比 rand() 更随机）
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_int_distribution<> dis(1000, 9999); // 固定4位随机数
        int randomNum = dis(gen);

        // 3. 拼接 Token：tk_时间戳_随机数_用户名_角色
        // 即使同一秒内多次登录，纳秒级时间戳和随机数也能确保完全不同
        string current_role = row[1];
        string token = "tk_" + to_string(randomNum) + "_" + current_role;

        {
            std::lock_guard<std::mutex> lock(sessionLock);
            // 将 token 存入 session 映射
            sessions[token] = { stoi(row[0]), user, current_role };
        }
        // 登录成功后，可以预先加载或重置该用户的虚拟图
        getOrCreateUserGraph(stoi(row[0]));
        crow::json::wvalue out;
        out["token"] = token;
        out["role"] = current_role;
        
        mysql_free_result(res); mysql_close(conn);
        return crow::response(out);
    });
    //[登出]
    CROW_ROUTE(app, "/api/auth/logout").methods("POST"_method)
    ([](const crow::request& req) {
        string token = req.get_header_value("Authorization");
        int uid = -1;
        {
            std::lock_guard<std::mutex> lock(sessionLock);
            if(sessions.count(token)) {
                uid = sessions[token].id;
                sessions.erase(token); // 销毁 Session
            }
        }
        // 登出时销毁虚拟图以释放内存
        if (uid != -1) {
            std::lock_guard<std::mutex> lock(sessionMutex);
            userSessionGraphs.erase(uid);
        }
        return crow::response(200, "Logged out");
    });

    //-------申请与审批-------
    // [提交申请]
    CROW_ROUTE(app, "/api/user/request").methods("POST"_method)
    ([](const crow::request& req) {
        int uid = getAuthId(req);
        if (uid == -1) return crow::response(401, "Please login");

        auto body = crow::json::load(req.body);
        if (!body.has("action") || !body.has("content")) return crow::response(400, "Invalid request");
    //将具体内容序列化为字符串存储
        string action = body["action"].s();     // ADD_CITY, ADD_ROUTE, DEL_CITY, DEL_ROUTE, UPDATE_ROUTE_FIELD
        // 将 body["content"] 转换为 wvalue 后再进行序列化
        string content = crow::json::wvalue(body["content"]).dump();
    

        MYSQL* conn = GetConn();
        string sql = "INSERT INTO ChangeRequests (user_id, action_type, content, status) VALUES (" 
                    + to_string(uid) + ", '" + action + "', '" + content + "', 'pending')";
        
        mysql_query(conn, sql.c_str());
        mysql_close(conn);
        return crow::response(200, "Request submitted");
    });
    //管理员审批
    // [查看待处理列表]
    CROW_ROUTE(app, "/api/admin/check").methods("GET"_method)
    ([](const crow::request& req) {
        if (!isAdmin(req)) return crow::response(403, "Admin only");

        MYSQL* conn = GetConn();
        mysql_query(conn, "SELECT r.request_id, u.username, r.action_type, r.content FROM ChangeRequests r JOIN Users u ON r.user_id = u.user_id WHERE r.status='pending'");
        
        MYSQL_RES* res = mysql_store_result(conn);
        crow::json::wvalue list;
        list["requests"] = crow::json::wvalue::list();
        int i = 0;
        while (auto row = mysql_fetch_row(res)) {
            list["requests"][i]["id"] = stoi(row[0]);
            list["requests"][i]["user"] = row[1];
            list["requests"][i]["action"] = row[2];
            list["requests"][i]["content"] = row[3]; // 前端接收后需用 JSON.parse 解析
            i++;
        }
        mysql_free_result(res); mysql_close(conn);
        return crow::response(list);
    });

    CROW_ROUTE(app, "/api/admin/approve").methods("POST"_method)
    ([](const crow::request& req) {
        if (!isAdmin(req)) return crow::response(403, "Admin only");
    
        auto body = crow::json::load(req.body);
        if (!body || !body.has("id") || !body.has("decision")) return crow::response(400, "Missing parameters");
    
        int requestId = body["id"].i();
        string decision = body["decision"].s(); 
    
        MYSQL* conn = GetConn();
        if (!conn) return crow::response(500, "DB connection failed");
    
        string checkSql = "SELECT action_type, content, status FROM ChangeRequests WHERE request_id=" + to_string(requestId);
        if (mysql_query(conn, checkSql.c_str())) {
            mysql_close(conn);
            return crow::response(500, "Query failed");
        }
        
        MYSQL_RES* res = mysql_store_result(conn);
        MYSQL_ROW row = mysql_fetch_row(res);
    
        if (!row) {
            mysql_free_result(res); mysql_close(conn);
            return crow::response(404, "Request ID not found");
        }
    
        string action = row[0];
        string contentStr = row[1];
        string currentStatus = row[2];
        mysql_free_result(res); // 提前释放，后面要执行新查询
    
        if (currentStatus != "pending") {
            mysql_close(conn);
            return crow::response(400, "Request already processed");
        }
    
        // --- 2. 处理逻辑 ---
        bool success = false;
        string execError = "";
    
        if (decision == "rejected") {
            string updateSql = "UPDATE ChangeRequests SET status='rejected' WHERE request_id=" + to_string(requestId);
            if (mysql_query(conn, updateSql.c_str()) == 0) success = true;
        } 
        else if (decision == "approved") {
            auto data = crow::json::load(contentStr);
            string finalSql = "";
    
            // 定义辅助 lambda：防止 SQL 注入的转义
            auto escape = [&](string val) {
                char* buf = new char[val.length() * 2 + 1];
                mysql_real_escape_string(conn, buf, val.c_str(), val.length());
                string res(buf);
                delete[] buf;
                return res;
            };
    
            if (action == "ADD_CITY") {
                finalSql = "INSERT INTO Cities (name, admin_id) VALUES ('" + 
                           escape(data["name"].s()) + "', '" + escape(data["admin"].s()) + "')";
            } 
            else if (action == "DEL_CITY") {
                string name = escape(data["name"].s());
                // 删除城市前先删相关的边
                mysql_query(conn, ("DELETE FROM arc_data WHERE from_city='" + name + "' OR to_city='" + name + "'").c_str());
                finalSql = "DELETE FROM Cities WHERE name='" + name + "'";
            } 
            else if (action == "ADD_ROUTE") {
                // 假设表结构列名为: from_city, to_city, transport, depart_time, arrive_time, cost, number, duration, status
                char sqlBuf[2048];
                snprintf(sqlBuf, sizeof(sqlBuf), 
                    "INSERT INTO arc_data (from_city, to_city, transport, depart_time, arrive_time, cost, number, duration, status) "
                    "VALUES ('%s','%s','%s','%s','%s',%d,'%s',%d,'active')",
                    escape(data["from"].s()).c_str(), 
                    escape(data["to"].s()).c_str(), 
                    escape(data["transport"].s()).c_str(),
                    escape(data["depart"].s()).c_str(), 
                    escape(data["arrive"].s()).c_str(), 
                    (int)data["cost"].i(),
                    escape(data["number"].s()).c_str(), 
                    (int)data["duration"].i()
                );
                finalSql = sqlBuf;
            }
            else if (action == "DEL_ROUTE") {
                finalSql = "DELETE FROM arc_data WHERE number='" + escape(data["number"].s()) + "'";
            }
            else if (action == "UPDATE_ROUTE_FIELD" || action == "MODIFY_ROUTE_FIELD") {
                // 允许两种 Action 命名，增强兼容性
                string col = data["column"].s();
                string routeNum = escape(data["number"].s());
                string newVal = escape(data["value"].s());
                if (col == "cost" || col == "status" || col == "depart_time" || 
                    col == "arrive_time" || col == "transport" || col == "depart" || col == "arrive") {
                    
                    // 自动将前端可能的简写映射为数据库实际字段名
                    string dbFieldName = col;
                    if (col == "depart") dbFieldName = "depart_time";
                    if (col == "arrive") dbFieldName = "arrive_time";
            
                    finalSql = "UPDATE arc_data SET " + dbFieldName + "='" + newVal + 
                               "' WHERE number='" + routeNum + "'";
                } else {
                    execError = "Forbidden column update: " + col;
                }
            }
    
            // 执行业务 SQL
        if (!finalSql.empty()) {
            if (mysql_query(conn, finalSql.c_str()) == 0) {
                // 检查是否有行受影响（防止删除不存在的记录显示成功）
                if (mysql_affected_rows(conn) > 0) {
                    // 业务操作真正生效了
                    string upSql = "UPDATE ChangeRequests SET status='approved' WHERE request_id=" + to_string(requestId);
                    if (mysql_query(conn, upSql.c_str()) == 0) {
                        success = true;
                        SyncFromDB(); // 业务和状态更新都成功后，同步内存
                    } else {
                        execError = "Logic executed but failed to update ChangeRequests status: " + string(mysql_error(conn));
                    }
                } else {
                    // 逻辑失败：数据库里没这条数据
                    execError = "Operation failed: The target record (city or route) does not exist in the database.";
                    cerr << "Logical Failure for SQL: " << finalSql << endl;
                }
            } else {
                // 数据库语法或约束错误
                execError = mysql_error(conn);
                cerr << "DB Error: " << execError << "\nSQL: " << finalSql << endl;
            }
        }
        } else {
            // 无效的审批决定
            mysql_close(conn);
            return crow::response(400, "Invalid decision: must be 'approved' or 'rejected'");
        }

        // 清理连接并返回结果
        mysql_close(conn);

        if (success) {
            return crow::response(200, "Success");
        } else {
            crow::json::wvalue errorRes;
            errorRes["error"] = execError.empty() ? "Operation failed due to logical error" : execError;
            return crow::response(400, errorRes);
        }
    });



    // ---------- 测试接口 ----------
    CROW_ROUTE(app, "/api/ping")
    ([]{
        crow::json::wvalue res;
        res["status"] = "ok";
        res["msg"] = "backend alive";
        return res;
    });

    // ---------- 获取服务器时间 ----------
    CROW_ROUTE(app, "/api/time")([]() {
        MYSQL* conn = GetConn();
        if (!conn) return crow::response(500, "DB connect failed");

        if (mysql_query(conn, "SELECT NOW()")) {
            string err = mysql_error(conn);
            mysql_close(conn);
            return crow::response(500, "MySQL query error: " + err);
        }

        MYSQL_RES* res = mysql_store_result(conn);
        if (!res) {
            mysql_close(conn);
            return crow::response(500, "MySQL store result failed");
        }

        MYSQL_ROW row = mysql_fetch_row(res);
        string time = row ? row[0] : "no data";

        mysql_free_result(res);
        mysql_close(conn);

        crow::json::wvalue json;
        json["time"] = time;
        return crow::response(json.dump());
    });
    //游客操作部分
    // 1. 查询最短路径（基于全局图）
    CROW_ROUTE(app, "/api/query/shortest_path")
    .methods("POST"_method)([&](const crow::request& req){
        if (req.method == "OPTIONS"_method) return crow::response(204);
        std::shared_lock<std::shared_mutex> lock(globalGraphLock); // 读锁
        auto body = crow::json::load(req.body);
        if (!body || !body.has("from") || !body.has("to") || !body.has("strategy"))
            return crow::response(400, "Missing parameters");

        string from = body["from"].s();
        string to = body["to"].s();
        string stratStr = body["strategy"].s();
        string transportFilter = body.has("transport") ? std::string(body["transport"].s()) : std::string("");
        int startTimeMin = body.has("start_time") ? parseTime(body["start_time"].s()) : 0;
        // 解析 hurry_index (0.0 ~ 1.0) ---
        float hurryIndex = body.has("hurry_index") ? (float)body["hurry_index"].d() : 0.5f;
        int startIdx = globalGraph.findCityIndex(from);
        int endIdx = globalGraph.findCityIndex(to);

        if (startIdx == -1 || endIdx == -1) 
            return crow::response(404, "City not found in global network");

        Strategy strategy ;
        if (stratStr == "fastest") strategy = Strategy::FASTEST;
        else if (stratStr == "cheapest") strategy = Strategy::CHEAPEST;
        else strategy = Strategy::COMPREHENSIVE; // 默认或匹配 "comprehensive"
        // 使用 globalGraph 进行计算
        crow::json::wvalue result = dijkstraAPI(globalGraph, startIdx, endIdx, strategy, transportFilter, startTimeMin, hurryIndex);
        auto res = crow::response(result);
        return res;
    });

    // 2. 展示当前所有交通信息 (JSON 列表)
    CROW_ROUTE(app, "/api/query/show")([&](const crow::request& req)  {
        if (req.method == "OPTIONS"_method) return crow::response(204);
        // 【补锁】开始遍历 globalGraph 前加读锁
        std::shared_lock<std::shared_mutex> lock(globalGraphLock); 
        crow::json::wvalue res;
        res["routes"] = crow::json::wvalue::list();
        int count = 0;

        for (int i = 0; i < globalGraph.cityCount && count < 100; ++i) {
            if (!globalGraph.cityArray[i].active) continue;
            for (EdgeNode* e = globalGraph.cityArray[i].firstEdge; e && count < 100 ; e = e->next) {
                if (!globalGraph.cityArray[e->to].active) continue;
                crow::json::wvalue item;
                item["from"] = globalGraph.cityArray[i].name;
                item["to"] = globalGraph.cityArray[e->to].name;
                item["transport"] = e->transport;
                item["number"] = e->number;
                item["depart"] = e->depart_time;
                item["arrive"] = e->arrive_time;
                item["cost"] = e->cost;
                item["status"] = e->status;
                res["routes"][count++] = std::move(item);
            }
        }
        auto response = crow::response(res);
        return response;
    });

    // ---------- 管理员操作部分 ----------
    CROW_ROUTE(app, "/api/admin/show")
    ([&](const crow::request& req) { // 1. 确保传入 req
        if (!isAdmin(req)) return crow::response(403, "Admin only");
        std::shared_lock<std::shared_mutex> lock(globalGraphLock); 
        crow::json::wvalue res;
        res["routes"] = crow::json::wvalue::list();
        int count = 0;

        // 建议：如果此时有 SyncFromDB 在运行，读取 globalGraph 可能会崩溃
        // 如果你的系统并发量高，这里可以加一个简单的互斥锁保护 globalGraph
        
        for (int i = 0; i < globalGraph.cityCount; ++i) {
            // 2. 关键检查：跳过不活跃（已删除）的来源城市
            if (!globalGraph.cityArray[i].active) continue; 

            for (EdgeNode* e = globalGraph.cityArray[i].firstEdge; e; e = e->next) {
                // 3. 关键检查：跳过目标城市是不活跃的边
                if (!globalGraph.cityArray[e->to].active) continue;

                crow::json::wvalue item;
                item["from"] = globalGraph.cityArray[i].name;
                item["to"] = globalGraph.cityArray[e->to].name;
                item["transport"] = e->transport;
                item["number"] = e->number;
                item["depart"] = e->depart_time;
                item["arrive"] = e->arrive_time;
                item["cost"] = e->cost;
                item["status"] = e->status;
                
                // 使用 push_back 的标准写法
                res["routes"][count++] = std::move(item);
            }
        }
        
        auto response = crow::response(res);
        response.add_header("Access-Control-Allow-Origin", "*");
        response.add_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS"); // 允许 POST
        response.add_header("Access-Control-Allow-Headers", "Content-Type"); // 允许 JSON 格式
        return response;
    });
    // 添加城市
    CROW_ROUTE(app, "/api/admin/city")
    .methods("POST"_method)
    ([](const crow::request& req) {
        if (!isAdmin(req)) return crow::response(403, "Admin only");
        auto body = crow::json::load(req.body);
        if (!body || !body.has("cityName") || !body.has("admin"))
            return crow::response(400, "Missing cityName or admin field");

        string city = body["cityName"].s();
        string admin = body["admin"].s();
        if (admin.empty())
            return crow::response(400, "admin cannot be empty");

        MYSQL* conn = GetConn();
        if (!conn) return crow::response(500, "DB connect failed");

        string sql = "INSERT INTO Cities(name, admin_id) VALUES('" + city + "', '" + admin + "')";
        if (mysql_query(conn, sql.c_str())) {
            string err = mysql_error(conn);
            mysql_close(conn);
            return crow::response(500, err);
        }
        // 关键点：操作成功后同步内存图
        SyncFromDB(); 
        mysql_close(conn);
        auto res= crow::response(200, "city added");
        res.add_header("Access-Control-Allow-Origin", "*"); // 允许所有来源
        res.add_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS"); // 允许 POST
        res.add_header("Access-Control-Allow-Headers", "Content-Type"); // 允许 JSON 格式
        return res;
    });

    // 查询城市
    CROW_ROUTE(app, "/api/admin/city")
    ([](const crow::request& req) {
        if (!isAdmin(req)) return crow::response(403, "Admin only");
        crow::json::wvalue res;
        res["cities"] = crow::json::wvalue::list();

        MYSQL* conn = GetConn();
        if (!conn) return crow::response(500, "DB connect failed");

        if (mysql_query(conn, "SELECT name, admin_id FROM Cities")) {
            string err = mysql_error(conn);
            mysql_close(conn);
            return crow::response(500, err);
        }

        MYSQL_RES* result = mysql_store_result(conn);
        MYSQL_ROW row;
        auto& cities = res["cities"];

        while ((row = mysql_fetch_row(result))) {
            crow::json::wvalue item;
            item["name"] = row[0];
            item["admin"] = row[1] ? row[1] : "";
            cities[cities.size()] = std::move(item);
        }

        mysql_free_result(result);
        mysql_close(conn);
        auto response= crow::response(res);
        response.add_header("Access-Control-Allow-Origin", "*"); // 允许所有来源
        response.add_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS"); // 允许 POST
        response.add_header("Access-Control-Allow-Headers", "Content-Type"); // 允许 JSON 格式
        return response;
    });
    // 修改城市单个字段（按 admin 定位）
    CROW_ROUTE(app, "/api/admin/city")
    .methods("PATCH"_method)
    ([&](const crow::request& req){
        if (!isAdmin(req)) return crow::response(403, "Admin only");
        auto body = crow::json::load(req.body);
        if (!body || !body.has("admin") || !body.has("column") || !body.has("value"))
            return crow::response(400, "missing admin / column / value");

        string admin  = body["admin"].s();
        string column = body["column"].s();
        string value  = body["value"].s();

        MYSQL* conn = GetConn();
        if (!conn) return crow::response(500, "DB connect failed");

        char sql[512];
        snprintf(sql, sizeof(sql),
            "UPDATE Cities SET %s='%s' WHERE admin_id='%s'",
            column.c_str(), value.c_str(), admin.c_str());

        if (mysql_query(conn, sql)) {
            string err = mysql_error(conn);
            mysql_close(conn);
            return crow::response(500, err);
        }
        // 关键点：操作成功后同步内存图
        SyncFromDB();
        mysql_close(conn);
        auto res= crow::response(200, "city field updated");
        res.add_header("Access-Control-Allow-Origin", "*"); // 允许所有来源
        res.add_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS"); // 允许 POST
        res.add_header("Access-Control-Allow-Headers", "Content-Type"); // 允许 JSON 格式
        return res;
    });

    // 删除城市（同时删除相关边）
    CROW_ROUTE(app, "/api/admin/city")
    .methods("DELETE"_method)
    ([](const crow::request& req){
        if (!isAdmin(req)) return crow::response(403, "Admin only");
        auto name = req.url_params.get("name");
        if (!name) return crow::response(400, "missing city name");

        MYSQL* conn = GetConn();
        if (!conn) return crow::response(500, "DB connect failed");

        //删除所有涉及该城市的边
        char sql_edges[512];
        snprintf(sql_edges, sizeof(sql_edges),
            "DELETE FROM arc_data WHERE from_city='%s' OR to_city='%s'",
            name, name);

        if (mysql_query(conn, sql_edges)) {
            string err = mysql_error(conn);
            mysql_close(conn);
            return crow::response(500, "Failed to delete related edges: " + err);
        }

        //删除城市
        char sql_city[256];
        snprintf(sql_city, sizeof(sql_city),
            "DELETE FROM Cities WHERE name='%s'", name);

        if (mysql_query(conn, sql_city)) {
            string err = mysql_error(conn);
            mysql_close(conn);
            return crow::response(500, "Failed to delete city: " + err);
        }
        // 关键点：操作成功后同步内存图
        SyncFromDB();

        mysql_close(conn);
        auto res= crow::response(200, "city and related edges deleted");
        res.add_header("Access-Control-Allow-Origin", "*"); // 允许所有来源
        res.add_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS"); // 允许 POST
        res.add_header("Access-Control-Allow-Headers", "Content-Type"); // 允许 JSON 格式
        return res;
    });


    // ---------- 边节点操作 ----------
    // 添加边
    CROW_ROUTE(app, "/api/admin/route")
    .methods("POST"_method)
    ([](const crow::request& req){
        if (!isAdmin(req)) return crow::response(403, "Admin only");
        auto body = crow::json::load(req.body);
        if (!body)
            return crow::response(400, "invalid json");

        // 必填字段检查
        if (!body.has("from_city") || !body.has("to_city") ||
            !body.has("transport") || !body.has("depart_time") ||
            !body.has("arrive_time") || !body.has("cost") ||
            !body.has("number") || !body.has("duration"))
            return crow::response(400, "Missing required field(s)");

        string from = body["from_city"].s();
        string to   = body["to_city"].s();
        string transport = body["transport"].s();
        string depart = body["depart_time"].s();
        string arrive = body["arrive_time"].s();
        int cost = body["cost"].i();
        string number = body["number"].s();
        int duration = body["duration"].i();

        MYSQL* conn = GetConn();
        if (!conn) return crow::response(500, "DB connect failed");

        char sql[512];
        snprintf(sql, sizeof(sql),
            "INSERT INTO arc_data(from_city,to_city,transport,depart_time,arrive_time,cost,number,duration,status) "
            "VALUES('%s','%s','%s','%s','%s',%d,'%s',%d,'active')",
            from.c_str(), to.c_str(), transport.c_str(), depart.c_str(), arrive.c_str(), cost, number.c_str(), duration
        );

        if (mysql_query(conn, sql)) {
            string err = mysql_error(conn);
            mysql_close(conn);
            return crow::response(500, err);
        }
        // 关键点：操作成功后同步内存图
        SyncFromDB();

        mysql_close(conn);
        auto res= crow::response(200, "route added");
        res.add_header("Access-Control-Allow-Origin", "*"); // 允许所有来源
        res.add_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS"); // 允许 POST
        res.add_header("Access-Control-Allow-Headers", "Content-Type"); // 允许 JSON 格式
        return res;
    });

    // 查询边
    CROW_ROUTE(app, "/api/admin/route")
    ([] (const crow::request& req){
        if (!isAdmin(req)) return crow::response(403, "Admin only");
        crow::json::wvalue res;
        res["routes"] = crow::json::wvalue::list();

        MYSQL* conn = GetConn();
        if (!conn) return crow::response(500, "DB connect failed");

        const char* sql =
            "SELECT route_id, from_city, to_city, transport, depart_time, arrive_time, cost, number, duration, status FROM arc_data";

        if (mysql_query(conn, sql)) {
            string err = mysql_error(conn);
            mysql_close(conn);
            return crow::response(500, err);
        }

        MYSQL_RES* result = mysql_store_result(conn);
        MYSQL_ROW row;
        auto& routes = res["routes"];

        while ((row = mysql_fetch_row(result))) {
            crow::json::wvalue item;
            item["route_id"]    = row[0] ? stoi(row[0]) : 0;
            item["from_city"]   = row[1] ? row[1] : "";
            item["to_city"]     = row[2] ? row[2] : "";
            item["transport"]   = row[3] ? row[3] : "";
            item["depart_time"] = row[4] ? row[4] : "";
            item["arrive_time"] = row[5] ? row[5] : "";
            item["cost"]        = row[6] ? stoi(row[6]) : 0;
            item["number"]      = row[7] ? row[7] : "";
            item["duration"]    = row[8] ? stoi(row[8]) : 0;
            item["status"]      = row[9] ? row[9] : "";
            routes[routes.size()] = std::move(item);
        }

        mysql_free_result(result);
        mysql_close(conn);
        auto response= crow::response(res);
        response.add_header("Access-Control-Allow-Origin", "*"); // 允许所有来源
        response.add_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS"); // 允许 POST
        response.add_header("Access-Control-Allow-Headers", "Content-Type"); // 允许 JSON 格式
        return response;
    });

    // 修改边单个字段（按 number 定位）
    CROW_ROUTE(app, "/api/admin/route")
    .methods("PATCH"_method)
    ([](const crow::request& req){
        if (!isAdmin(req)) return crow::response(403, "Admin only");
        auto body = crow::json::load(req.body);
        if (!body || !body.has("number") || !body.has("column") || !body.has("value"))
            return crow::response(400, "missing number / column / value");

        string number = body["number"].s();
        string column = body["column"].s();
        string value  = body["value"].s();

        MYSQL* conn = GetConn();
        if (!conn) return crow::response(500, "DB connect failed");

        char sql[512];
        snprintf(sql, sizeof(sql),
            "UPDATE arc_data SET %s='%s' WHERE number='%s'",
            column.c_str(), value.c_str(), number.c_str());

        if (mysql_query(conn, sql)) {
            string err = mysql_error(conn);
            mysql_close(conn);
            return crow::response(500, err);
        }
        // 关键点：操作成功后同步内存图
        SyncFromDB();

        mysql_close(conn);
        auto res= crow::response(200, "route field updated");
        res.add_header("Access-Control-Allow-Origin", "*"); // 允许所有来源
        res.add_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS"); // 允许 POST
        res.add_header("Access-Control-Allow-Headers", "Content-Type"); // 允许 JSON 格式
        return res;
    });

    // 删除边（仅按 number 删除）
    CROW_ROUTE(app, "/api/admin/route")
    .methods("DELETE"_method)
    ([](const crow::request& req){
        if (!isAdmin(req)) return crow::response(403, "Admin only");
        // 获取 URL 参数 number
        auto number = req.url_params.get("number");
        if (!number)
            return crow::response(400, "missing number"); // 必须提供 number

        // 获取数据库连接
        MYSQL* conn = GetConn();
        if (!conn)
            return crow::response(500, "DB connect failed");

        // 构造 SQL
        char sql[512];
        snprintf(sql, sizeof(sql),
            "DELETE FROM arc_data WHERE number='%s'", number);

        // 执行 SQL
        if (mysql_query(conn, sql)) {
            string err = mysql_error(conn);
            mysql_close(conn);
            return crow::response(500, err);
        }
        // 关键点：操作成功后同步内存图
        SyncFromDB();

        mysql_close(conn);
        auto res= crow::response(200, "route deleted by number");
        res.add_header("Access-Control-Allow-Origin", "*"); // 允许所有来源
        res.add_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS"); // 允许 POST
        res.add_header("Access-Control-Allow-Headers", "Content-Type"); // 允许 JSON 格式
        return res;
    });
    //文件上传同步数据库
    // ---------- 管理员文件上传覆盖数据库 ----------
    CROW_ROUTE(app, "/api/admin/upload_db")
    .methods("POST"_method)
    ([](const crow::request& req) {
        if (!isAdmin(req)) return crow::response(403, "Admin only");
        // 1. 解析 Multipart 文件
        crow::multipart::message msg(req);
        auto it = msg.part_map.find("file");
        if (it == msg.part_map.end()) {
            return crow::response(400, "No file uploaded");
        }

        // 2. 将文件内容转为 JSON
        std::string file_content = it->second.body;
        auto json_data = crow::json::load(file_content);
        if (!json_data) {
            return crow::response(400, "Invalid JSON format");
        }

        // 3. 连接数据库
        MYSQL* conn = GetConn();
        if (!conn) return crow::response(500, "DB connect failed");

        // 开启“简单事务”思想：先清空，再插入
        // 由于 arc_data 依赖城市名，建议先清空边，再清空城市
        mysql_query(conn, "DELETE FROM arc_data");
        mysql_query(conn, "DELETE FROM Cities");

        // 4. 第一阶段：插入城市
        if (json_data.has("cities")) {
            for (const auto& city : json_data["cities"]) {
                if (!city.has("name") || !city.has("admin")) continue;
                
                // 强制转换为 std::string
                string sql = "INSERT INTO Cities(name, admin_id) VALUES('" + 
                            std::string(city["name"].s()) + "', '" + std::string(city["admin"].s()) + "')";
                if (mysql_query(conn, sql.c_str())) {
                    cerr << "SQL Error (City Insert): " << mysql_error(conn) << endl;
                }
            }
        }

        // 5. 第二阶段：插入边 (交通路线)
        if (json_data.has("routes")) {
            for (const auto& route : json_data["routes"]) {
                if (!route.has("from") || !route.has("to") || !route.has("transport") || 
                    !route.has("cost") || !route.has("number")) continue;

                char sql[1024];
                // 修复：转换后调用 .c_str()
                snprintf(sql, sizeof(sql),
                    "INSERT INTO arc_data(from_city, to_city, transport, depart_time, arrive_time, cost, number, duration, status) "
                    "VALUES('%s', '%s', '%s', '%s', '%s', %d, '%s', %d, '%s')",
                    std::string(route["from"].s()).c_str(),
                    std::string(route["to"].s()).c_str(),
                    std::string(route["transport"].s()).c_str(),
                    std::string(route["depart_time"].s()).c_str(),
                    std::string(route["arrive_time"].s()).c_str(),
                    (int)route["cost"].i(),
                    std::string(route["number"].s()).c_str(),
                    (int)route["duration"].i(),
                    route.has("status") ? std::string(route["status"].s()).c_str() : "active"
                );

                if (mysql_query(conn, sql)) {
                    cerr << "SQL Error (Route Insert): " << mysql_error(conn) << endl;
                }
            }
        }

        

        mysql_close(conn);

        // 6. 关键步骤：操作成功后，强制同步全局内存图
        if (SyncFromDB()) {
            crow::json::wvalue res;
            res["status"] = "ok";
            res["msg"] = "Database overwritten and globalGraph synchronized";
            auto response =crow::response(res);
            response.add_header("Access-Control-Allow-Origin", "*"); // 允许所有来源
            response.add_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS"); // 允许 POST
            response.add_header("Access-Control-Allow-Headers", "Content-Type"); // 允许 JSON 格式
            return response;
        } else {
            auto response= crow::response(500, "DB updated but memory sync failed");
            response.add_header("Access-Control-Allow-Origin", "*"); // 允许所有来源
            response.add_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS"); // 允许 POST
            response.add_header("Access-Control-Allow-Headers", "Content-Type"); // 允许 JSON 格式
            return response;
        }
    });

    // ---------- 虚拟化运算部分（用户独立图） ----------
    CROW_ROUTE(app, "/api/user/reset").methods("POST"_method)
    ([](const crow::request& req) {
        int uid = getAuthId(req);
        if (uid == -1) return crow::response(401, "Please login");

        UserGraph& userGraph = getOrCreateUserGraph(uid);
        {
            std::shared_lock<std::shared_mutex> lockGlobal(globalGraphLock);
            userGraph.cloneFrom(globalGraph);
        }
        auto res= crow::response(200, "User graph reset to global state");
        res.add_header("Access-Control-Allow-Origin", "*"); // 允许所有来源
        res.add_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS"); // 允许 POST
        res.add_header("Access-Control-Allow-Headers", "Content-Type"); // 允许 JSON 格式
        return res;
    });

    // ---------- 城市操作 ----------

    // 查询所有城市（从用户专属图读取）
    CROW_ROUTE(app, "/api/user/show")
    ([&](const crow::request& req) {
        // 1. 获取当前登录用户 ID
        int uid = getAuthId(req);
        if (uid == -1) return crow::response(401, "Please login");

        // 2. 获取该用户的专属虚拟图（而不是全局图）
        UserGraph& userGraph = getOrCreateUserGraph(uid);

        crow::json::wvalue res;
        res["routes"] = crow::json::wvalue::list();
        int count = 0;

        // 3. 加锁保护，防止读取时其他线程正在修改该用户的虚拟图
        std::lock_guard<std::mutex> lock(sessionMutex);

        for (int i = 0; i < userGraph.cityCount; ++i) {
            // 4. 关键：只显示活跃的城市
            if (!userGraph.cityArray[i].active) continue;

            for (EdgeNode* e = userGraph.cityArray[i].firstEdge; e; e = e->next) {
                // 5. 关键：确保目标城市也是活跃的
                if (!userGraph.cityArray[e->to].active) continue;

                crow::json::wvalue item;
                item["from"] = userGraph.cityArray[i].name;
                item["to"] = userGraph.cityArray[e->to].name;
                item["transport"] = e->transport;
                item["number"] = e->number;
                item["depart"] = e->depart_time;
                item["arrive"] = e->arrive_time;
                item["cost"] = e->cost;
                item["status"] = e->status;
                
                res["routes"][count++] = std::move(item);
            }
        }

        auto response = crow::response(res);
        response.add_header("Access-Control-Allow-Origin", "*");
        response.add_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS"); // 允许 POST
        response.add_header("Access-Control-Allow-Headers", "Content-Type"); // 允许 JSON 格式
        return response;
    });

    // 新增虚拟城市（持久化到用户专属图）
    CROW_ROUTE(app, "/api/user/city").methods("POST"_method)
    ([](const crow::request& req) {
        int uid = getAuthId(req);
        if (uid == -1) return crow::response(401, "Please login");

        auto body = crow::json::load(req.body);
        if (!uid || !body || !body.has("name") || !body.has("admin"))
            return crow::response(400, "missing name or admin");

        UserGraph& userGraph = getOrCreateUserGraph(uid);
        if (!userGraph.addCity(body["name"].s(), body["admin"].s()))
            return crow::response(500, "City limit reached");

        auto res= crow::response(200, "Virtual city added");
        res.add_header("Access-Control-Allow-Origin", "*"); // 允许所有来源
        res.add_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS"); // 允许 POST
        res.add_header("Access-Control-Allow-Headers", "Content-Type"); // 允许 JSON 格式
        return res;
    });

    // 删除城市（持久化到用户专属图）
    CROW_ROUTE(app, "/api/user/city").methods("DELETE"_method)
    ([](const crow::request& req) {
        int uid = getAuthId(req);
        if (uid == -1) return crow::response(401, "Please login");

        auto name = req.url_params.get("name");
        if (!name) return crow::response(400, "missing name");

        UserGraph& userGraph = getOrCreateUserGraph(uid);
        int idx = userGraph.findCityIndex(name);
        if (idx == -1) return crow::response(404, "city not found");

        userGraph.deleteCity(idx);
        auto res= crow::response(200, "Virtual city deleted");
        res.add_header("Access-Control-Allow-Origin", "*"); // 允许所有来源
        res.add_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS"); // 允许 POST
        res.add_header("Access-Control-Allow-Headers", "Content-Type"); // 允许 JSON 格式
        return res;
    });

    // 修改城市字段（持久化到用户专属图）
    CROW_ROUTE(app, "/api/user/city").methods("PATCH"_method)
    ([](const crow::request& req) {
        int uid = getAuthId(req);
        if (uid == -1) return crow::response(401, "Please login");

        auto body = crow::json::load(req.body);
        if (!body || !body.has("name") || !body.has("column") || !body.has("value"))
            return crow::response(400, "missing name/column/value");

        UserGraph& userGraph = getOrCreateUserGraph(uid);
        int idx = userGraph.findCityIndex(body["name"].s());
        if (idx == -1) return crow::response(404, "city not found");

        if (!userGraph.updateCityField(idx, body["column"].s(), body["value"].s()))
            return crow::response(400, "unknown column");

        auto res= crow::response(200, "Virtual city updated");
        res.add_header("Access-Control-Allow-Origin", "*"); // 允许所有来源
        res.add_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS"); // 允许 POST
        res.add_header("Access-Control-Allow-Headers", "Content-Type"); // 允许 JSON 格式
        return res;
    });

    // ---------- 边节点操作 ----------

    // 查询所有边（从用户专属图读取）
    CROW_ROUTE(app, "/api/user/route")([](const crow::request& req) {
        int uid = getAuthId(req);
        if (uid == -1) return crow::response(401, "Please login");

        UserGraph& userGraph = getOrCreateUserGraph(uid);
        crow::json::wvalue res;
        res["routes"] = crow::json::wvalue::list();
        int idx = 0;

        for (int i = 0; i < userGraph.cityCount; ++i) {
            for (EdgeNode* e = userGraph.cityArray[i].firstEdge; e; e = e->next) {
                crow::json::wvalue item;
                item["from"] = userGraph.cityArray[i].name;
                item["to"] = userGraph.cityArray[e->to].name;
                item["transport"] = e->transport;
                item["depart_time"] = e->depart_time;
                item["arrive_time"] = e->arrive_time;
                item["cost"] = e->cost;
                item["number"] = e->number;
                item["duration"] = e->duration;
                item["status"] = e->status;
                res["routes"][idx++] = std::move(item);
            }
        }
        auto response= crow::response(res);
        response.add_header("Access-Control-Allow-Origin", "*"); // 允许所有来源
        response.add_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS"); // 允许 POST
        response.add_header("Access-Control-Allow-Headers", "Content-Type"); // 允许 JSON 格式
        return response;
    });

    // 新增边（持久化到用户专属图）
    CROW_ROUTE(app, "/api/user/route").methods("POST"_method)
    ([](const crow::request& req) {
        int uid = getAuthId(req);
        if (uid == -1) return crow::response(401, "Please login");

        auto body = crow::json::load(req.body);
        if (!body || !body.has("from") || !body.has("to"))
            return crow::response(400, "missing routing fields");

        UserGraph& userGraph = getOrCreateUserGraph(uid);
        int fromIdx = userGraph.findCityIndex(body["from"].s());
        int toIdx = userGraph.findCityIndex(body["to"].s());
        if (fromIdx == -1 || toIdx == -1) return crow::response(404, "city not found");

        userGraph.addEdge(fromIdx, toIdx, body["transport"].s(), body["depart_time"].s(),
                        body["arrive_time"].s(), body["cost"].i(), body["number"].s(),
                        body["duration"].i(), "active");

        auto res= crow::response(200, "Virtual route added");
        res.add_header("Access-Control-Allow-Origin", "*"); // 允许所有来源
        res.add_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS"); // 允许 POST
        res.add_header("Access-Control-Allow-Headers", "Content-Type"); // 允许 JSON 格式
        return res;
    });

    // 删除边（从用户专属图中删除）
    CROW_ROUTE(app, "/api/user/route").methods("DELETE"_method)
    ([](const crow::request& req) {
        int uid = getAuthId(req);
        if (uid == -1) return crow::response(401, "Please login");

        auto number = req.url_params.get("number");
        if (!number) return crow::response(400, "missing number");

        UserGraph& userGraph = getOrCreateUserGraph(uid);
        if (!userGraph.deleteEdge(number))
            return crow::response(404, "route not found in virtual graph");

        auto res= crow::response(200, "Virtual route deleted");
        res.add_header("Access-Control-Allow-Origin", "*"); // 允许所有来源
        res.add_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS"); // 允许 POST
        res.add_header("Access-Control-Allow-Headers", "Content-Type"); // 允许 JSON 格式
        return res;
    });

    // 修改边字段（持久化到用户专属图）
    CROW_ROUTE(app, "/api/user/route").methods("PATCH"_method)
    ([](const crow::request& req) {
        int uid = getAuthId(req);
        if (uid == -1) return crow::response(401, "Please login");

        auto body = crow::json::load(req.body);
        if (!body || !body.has("number") || !body.has("column") || !body.has("value"))
            return crow::response(400, "missing number/column/value");

        UserGraph& userGraph = getOrCreateUserGraph(uid);
        if (!userGraph.updateEdgeField(body["number"].s(), body["column"].s(), body["value"].s()))
            return crow::response(404, "route not found or unknown column");

        auto res= crow::response(200, "Virtual route updated");
        res.add_header("Access-Control-Allow-Origin", "*"); // 允许所有来源
        res.add_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS"); // 允许 POST
        res.add_header("Access-Control-Allow-Headers", "Content-Type"); // 允许 JSON 格式
        return res;
    });
    //上传文件
    CROW_ROUTE(app, "/api/user/upload")
    .methods("POST"_method)
    ([](const crow::request& req) {
        int uid = getAuthId(req);
        if (uid == -1) return crow::response(401, "Please login");
        // 1. 获取用户 ID
        // 2. 解析 Multipart 数据
        crow::multipart::message msg(req);
        auto it = msg.part_map.find("file"); // 假设前端上传字段名为 "file"
        if (it == msg.part_map.end()) {
            return crow::response(400, "No file uploaded");
        }

        // 3. 将上传的文件内容解析为 JSON
        std::string file_content = it->second.body;
        auto json_data = crow::json::load(file_content);
        if (!json_data) {
            return crow::response(400, "Invalid JSON format in file");
        }

        // 4. 获取用户专属图并清空
        UserGraph& userGraph = getOrCreateUserGraph(uid);
        {
            // 建议加锁以保证操作原子性
            std::lock_guard<std::mutex> lock(sessionMutex);
            userGraph.clear(); // 清空旧数据

            // 5. 第一阶段：导入城市
        if (json_data.has("cities")) {
            for (const auto& city : json_data["cities"]) {
                if (!city.has("name") || !city.has("admin")) continue;
                
                // 修改点：显式转为 std::string
                userGraph.addCity(std::string(city["name"].s()), std::string(city["admin"].s()));
            }
        }

            // 6. 第二阶段：导入边
            if (json_data.has("routes")) {
                for (const auto& route : json_data["routes"]) {
                    if (!route.has("from") || !route.has("to") || !route.has("cost")) continue;

                    int u = userGraph.findCityIndex(std::string(route["from"].s()));
                    int v = userGraph.findCityIndex(std::string(route["to"].s()));

                    if (u != -1 && v != -1) {
                        userGraph.addEdge(
                            u, v,
                            std::string(route["transport"].s()),
                            std::string(route["depart_time"].s()),
                            std::string(route["arrive_time"].s()),
                            route["cost"].i(),
                            std::string(route["number"].s()),
                            route["duration"].i(),
                            // 修复：确保三元表达式两边类型一致
                            route.has("status") ? std::string(route["status"].s()) : std::string("active")
                        );
                    }
                }
            }
        }

        crow::json::wvalue res;
        res["status"] = "ok";
        res["msg"] = "Virtual graph overwritten successfully from file";
        res["cityCount"] = userGraph.cityCount;
        auto response= crow::response(res);
        response.add_header("Access-Control-Allow-Origin", "*"); // 允许所有来源
        response.add_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS"); // 允许 POST
        response.add_header("Access-Control-Allow-Headers", "Content-Type"); // 允许 JSON 格式
        return response;
    });

    // ---------- 查询最短路径（基于用户专属图进行计算） ----------
    CROW_ROUTE(app, "/api/user/shortest_path").methods("POST"_method)
    ([&](const crow::request& req) {
        int uid = getAuthId(req);
        if (uid == -1) return crow::response(401, "Please login");

        auto body = crow::json::load(req.body);
        if (!body || !body.has("from") || !body.has("to") || !body.has("strategy"))
            return crow::response(400, "Missing from, to, or strategy");

        // 获取用户当前的专属持久化图
        UserGraph& userGraph = getOrCreateUserGraph(uid);

        string fromCity = body["from"].s();
        string toCity = body["to"].s();
        string stratStr = body["strategy"].s();
        string transportFilter = body.has("transport") ? body["transport"].s() : std::string("");
        
        int startTimeMin = body.has("start_time") ? parseTime(body["start_time"].s()) : 0;
        float hurryIndex = body.has("hurry_index") ? (float)body["hurry_index"].d() : 0.5f;
        // 关键：在用户专属图中查找索引
        int startIdx = userGraph.findCityIndex(fromCity);
        int endIdx = userGraph.findCityIndex(toCity);

        if (startIdx == -1 || endIdx == -1) {
            return crow::response(404, "City not found in your virtual graph");
        }

        Strategy strategy;
        if (stratStr == "fastest") strategy = Strategy::FASTEST;
        else if (stratStr == "cheapest") strategy = Strategy::CHEAPEST;
        else strategy = Strategy::COMPREHENSIVE;
        // 关键：传入 userGraph 而不是 globalGraph
        crow::json::wvalue result = dijkstraAPI(userGraph, startIdx, endIdx, strategy, transportFilter, startTimeMin, hurryIndex);

        auto res= crow::response(result);
        res.add_header("Access-Control-Allow-Origin", "*"); // 允许所有来源
        res.add_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS"); // 允许 POST
        res.add_header("Access-Control-Allow-Headers", "Content-Type"); // 允许 JSON 格式
        return res;
    });


    
    // ---------- 启动服务器 ----------
    app.port(18080).multithreaded().run();
    cout << "Server running on port 18080" << endl;
    return 0;
}
//cmake .. -G "MinGW Makefiles" 
// //mingw32-make clean 
// //mingw32-make -j 
// //./server.exe