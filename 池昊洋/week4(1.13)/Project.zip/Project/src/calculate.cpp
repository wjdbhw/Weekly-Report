#include "graph.h"
#include "crow.h"
#include <iostream>
#include <string>
#include <queue>
#include <vector>
#include <limits>
#include <algorithm>
#include "calculate.h"

using namespace std;

static const double INF_DBL = numeric_limits<double>::max();
static const int INF_VAL = numeric_limits<int>::max();

// 解析时间字符串 "YYYY-MM-DD HH:MM:SS" 为自纪元以来的分钟数
int parseTime(const string& timeStr) {
    tm t{};
#ifdef _WIN32
    if (sscanf_s(timeStr.c_str(), "%d-%d-%d %d:%d:%d",
               &t.tm_year, &t.tm_mon, &t.tm_mday,
               &t.tm_hour, &t.tm_min, &t.tm_sec) != 6) {
        return 0;
    }
#else
    if (sscanf(timeStr.c_str(), "%d-%d-%d %d:%d:%d",
               &t.tm_year, &t.tm_mon, &t.tm_mday,
               &t.tm_hour, &t.tm_min, &t.tm_sec) != 6) {
        return 0;
    }
#endif
    t.tm_year -= 1900;
    t.tm_mon -= 1;
    t.tm_isdst = -1; 
    time_t timeStamp = mktime(&t);
    return static_cast<int>(timeStamp / 60);
}


//@brief Dijkstra 算法实现
//hurryIndex = 0.5f，默认值已在 calculate.h 声明
crow::json::wvalue dijkstraAPI(const UserGraph& graph,
                               int startIndex,
                               int endIndex,
                               Strategy strategy,
                               const string& transportFilter,
                               int startTimeMin,
                               float hurryIndex) 
{
    int n = graph.cityCount;
    
    // 数据类型使用 double 以保证综合评分的精度
    vector<double> dist(n, INF_DBL); 
    vector<int> prev(n, -1);
    vector<int> arriveTimeAtCity(n, INF_VAL); 
    vector<EdgeNode*> edgeUsed(n, nullptr);

    // 权重分配逻辑
    double w_time = static_cast<double>(hurryIndex);
    double w_cost = 1.0 - w_time;

    // 优先队列 {当前得分, 城市索引}
    using Node = pair<double, int>;
    priority_queue<Node, vector<Node>, greater<Node>> pq;

    // 初始化起点
    dist[startIndex] = 0.0;
    arriveTimeAtCity[startIndex] = startTimeMin;
    pq.push({0.0, startIndex});

    while (!pq.empty()) {
        auto [currentScore, u] = pq.top(); 
        pq.pop();

        if (u == endIndex) break;
        if (currentScore > dist[u]) continue;

        for (EdgeNode* e = graph.cityArray[u].firstEdge; e; e = e->next) {
            if (!graph.cityArray[e->to].active) continue; // 确保目标城市有效
            if (e->status == "inactive") continue;
            if (!transportFilter.empty() && e->transport != transportFilter) continue;

            int depart = parseTime(e->depart_time);
            int arrive = parseTime(e->arrive_time);

            // 时间合法性检查：必须在到达上一站之后才能出发
            if (depart < arriveTimeAtCity[u]) continue;

            int v = e->to;
            double edgeWeight = 0;

            //计算模型
            if (strategy == Strategy::CHEAPEST) {
                edgeWeight = static_cast<double>(e->cost);
            } 
            else if (strategy == Strategy::FASTEST) {
                // 最快路径权重 = 本段到达时间 - 上一段到达时间（包含等待时间）
                edgeWeight = static_cast<double>(arrive - arriveTimeAtCity[u]);
            } 
            else {
                // 综合评分 = (钱权重 * 价格) + (时间权重 * 消耗分钟)
                int duration = arrive - arriveTimeAtCity[u]; 
                edgeWeight = (w_cost * e->cost) + (w_time * duration);
            }

            // 松弛操作
            if (dist[u] + edgeWeight < dist[v]) {
                dist[v] = dist[u] + edgeWeight;
                arriveTimeAtCity[v] = arrive; // 物理到达时间必须更新，用于下一跳判断
                prev[v] = u;
                edgeUsed[v] = e;
                pq.push({dist[v], v});
            }
        }
    }

    crow::json::wvalue res;
    if (prev[endIndex] == -1 && startIndex != endIndex) {
        res["status"] = "fail";
        res["msg"] = "No path available under given constraints";
        return res;
    }

    // 构建路径结果
    vector<crow::json::wvalue> pathNodes;
    int finalCost = 0;
    int cur = endIndex;
    while (cur != -1) {
        crow::json::wvalue node;
        node["city"] = graph.cityArray[cur].name;
        node["admin"] = graph.cityArray[cur].admin;
        
        if (edgeUsed[cur]) {
            finalCost += edgeUsed[cur]->cost;
            crow::json::wvalue edgeJson;
            edgeJson["from_city"] = graph.cityArray[prev[cur]].name;
            edgeJson["to_city"] = graph.cityArray[cur].name;
            edgeJson["transport"] = edgeUsed[cur]->transport;
            edgeJson["depart_time"] = edgeUsed[cur]->depart_time;
            edgeJson["arrive_time"] = edgeUsed[cur]->arrive_time;
            edgeJson["cost"] = edgeUsed[cur]->cost;
            edgeJson["number"] = edgeUsed[cur]->number;
            node["incoming_edge"] = std::move(edgeJson);
        }
        pathNodes.push_back(std::move(node));
        cur = prev[cur];
    }

    reverse(pathNodes.begin(), pathNodes.end());
    crow::json::wvalue::list pathArr;
    for (auto& n : pathNodes) pathArr.push_back(std::move(n));

    // 结果输出
    res["status"] = "ok";
    res["strategy"] = (strategy == Strategy::COMPREHENSIVE ? "comprehensive" : 
                      (strategy == Strategy::FASTEST ? "fastest" : "cheapest"));
    res["total_cost"] = finalCost;
    res["total_duration_min"] = arriveTimeAtCity[endIndex] - startTimeMin;
    res["comprehensive_score"] = dist[endIndex];
    res["path"] = std::move(pathArr);

    return res;
}