#pragma once
#include "graph.h"
#include "crow.h"
#include <string>

enum class Strategy {
    FASTEST,
    CHEAPEST,
    COMPREHENSIVE // 综合评价（性价比）
};

// 声明解析时间函数
int parseTime(const std::string& timeStr);

// 声明 Dijkstra API
crow::json::wvalue dijkstraAPI(const UserGraph& graph,
                               int startIndex,
                               int endIndex,
                               Strategy strategy,
                               const std::string& transportFilter,
                               int startTimeMin,
                               float hurryIndex
                            );