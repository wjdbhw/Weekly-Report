#pragma once
#include <string>
using namespace std;

const int MAX_CITIES = 200; // 最大城市数
const int INF = 0x3f3f3f3f; // 表示不可达

// 边节点（邻接链表）
struct EdgeNode {
    int to;               // 目标城市在数组中的索引
    string transport;     // 交通工具类型
    string depart_time;   // 出发时间
    string arrive_time;   // 到达时间
    int cost;             // 费用
    string number;        // 交通编号
    int duration;         // 持续时间（分钟）
    string status;        // 状态

    EdgeNode* next;       // 链表指向下一条边

    // 构造函数
    EdgeNode(int t, const string& trans, const string& depart,
             const string& arrive, int c, const string& num, int dur,
             const string& stat)
        : to(t), transport(trans), depart_time(depart), arrive_time(arrive),
          cost(c), number(num), duration(dur), status(stat), next(nullptr) {}
};

// 城市节点
struct City {
    string name;          // 城市名称
    string admin;         // 管理员ID
    EdgeNode* firstEdge;  // 指向该城市的第一条边
    bool active;        // 标记该索引是否被占用
    City() : firstEdge(nullptr), active(false) {} // 默认为false
};

// 用户独立图结构
struct UserGraph {
    City cityArray[MAX_CITIES]; // 城市数组
    int cityCount;              // 当前城市数量

    UserGraph() : cityCount(0) {
        for (int i = 0; i < MAX_CITIES; i++){
            cityArray[i].firstEdge = nullptr;
            cityArray[i].active = false;}
    }
    // 必须添加析构函数
    ~UserGraph() {
        clear();
    }
    UserGraph(const UserGraph&) = delete;            // 禁止拷贝构造
    UserGraph& operator=(const UserGraph&) = delete; // 禁止赋值操作
    // ----------------------------
    // ---------- 城市操作 ----------
    // 清理链表内存
    void clear() {
        for (int i = 0; i < MAX_CITIES; i++) {
            EdgeNode* e = cityArray[i].firstEdge;
            while (e) {
                EdgeNode* tmp = e;
                e = e->next;
                delete tmp;
            }
            cityArray[i].firstEdge = nullptr;
            cityArray[i].active = false; 
            cityArray[i].name = ""; 
        }
        cityCount = 0;
    }

    // 添加城市
    bool addCity(const string& name, const string& admin) {
        // 寻找空位
        int targetIndex = -1;
        for (int i = 0; i < MAX_CITIES; i++) {
            if (!cityArray[i].active) {
                targetIndex = i;
                break;
            }
        }
    
        if (targetIndex == -1) return false; 
    
        cityArray[targetIndex].name = name;
        cityArray[targetIndex].admin = admin;
        cityArray[targetIndex].firstEdge = nullptr;
        cityArray[targetIndex].active = true; 
        
        // 更新 cityCount 为当前最大索引+1，或者仅仅作为统计使用
        if (targetIndex >= cityCount) cityCount = targetIndex + 1;
        return true;
    }
    
    // 查找城市下标
    int findCityIndex(const string& name) const {
        // 遍历到当前最大索引位置
        for (int i = 0; i < cityCount; ++i) {
            // 只有活跃的城市且名字匹配才返回索引
            if (cityArray[i].active && cityArray[i].name == name) {
                return i;
            }
        }
        return -1;
    }

    // 修改城市字段
    bool updateCityField(int index, const string& column, const string& value) {
        // 新增检查：索引无效或城市不活跃，直接返回失败
        if (index < 0 || index >= MAX_CITIES || !cityArray[index].active) return false;
    
        if (column == "name") cityArray[index].name = value;
        else if (column == "admin") cityArray[index].admin = value;
        else return false;
        return true;
    }

    // 删除城市（同时删除相关边）
    void deleteCity(int index) {
        if (index < 0 || index >= MAX_CITIES || !cityArray[index].active) return;
    
        // 1. 释放该城市出发的所有边
        EdgeNode* e = cityArray[index].firstEdge;
        while (e) {
            EdgeNode* tmp = e;
            e = e->next;
            delete tmp;
        }
        cityArray[index].firstEdge = nullptr;
    
        // 2. 遍历全图，删除所有指向该城市的边
        for (int i = 0; i < MAX_CITIES; ++i) {
            if (!cityArray[i].active) continue;
            EdgeNode* prev = nullptr;
            EdgeNode* cur = cityArray[i].firstEdge;
            while (cur) {
                if (cur->to == index) {
                    EdgeNode* tmp = cur;
                    if (prev) prev->next = cur->next;
                    else cityArray[i].firstEdge = cur->next;
                    cur = cur->next;
                    delete tmp;
                } else {
                    prev = cur;
                    cur = cur->next;
                }
            }
        }
    
        cityArray[index].active = false;
        cityArray[index].name = ""; 
    }

    // ---------- 边操作 ----------

    // 添加边（fromIndex -> toIndex）
    void addEdge(int fromIndex, int toIndex, const string& transport,
                 const string& depart, const string& arrive,
                 int cost, const string& number, int duration,
                 const string& status) {
        EdgeNode* edge = new EdgeNode(toIndex, transport, depart, arrive,
                                      cost, number, duration, status);
        edge->next = cityArray[fromIndex].firstEdge;
        cityArray[fromIndex].firstEdge = edge;
    }

    // 删除边（按 number）
    bool deleteEdge(const string& number) {
        for (int i = 0; i < cityCount; ++i) {
            if (!cityArray[i].active) continue; // 跳过不活跃城市
            EdgeNode* prev = nullptr;
            EdgeNode* cur = cityArray[i].firstEdge;
            while (cur) {
                if (cur->number == number) {
                    if (prev) prev->next = cur->next;
                    else cityArray[i].firstEdge = cur->next;
                    delete cur;
                    return true;
                }
                prev = cur;
                cur = cur->next;
            }
        }
        return false;
    }

    // 修改边字段（按 number）
    bool updateEdgeField(const string& number, const string& column, const string& value) {
        for (int i = 0; i < cityCount; ++i) {
            for (EdgeNode* e = cityArray[i].firstEdge; e; e = e->next) {
                if (!cityArray[i].active) continue; // 跳过不活跃城市
                if (e->number == number) {
                    if (column == "transport") e->transport = value;
                    else if (column == "depart_time") e->depart_time = value;
                    else if (column == "arrive_time") e->arrive_time = value;
                    else if (column == "cost") e->cost = stoi(value);
                    else if (column == "number") e->number = value;
                    else if (column == "duration") e->duration = stoi(value);
                    else if (column == "status") e->status = value;
                    else return false;
                    return true;
                }
            }
        }
        return false;
    }

    //深拷贝
    void cloneFrom(const UserGraph& src) {
        clear();
        cityCount = src.cityCount; 
        for (int i = 0; i < cityCount; ++i) {// 必须拷贝活跃状态
            cityArray[i].active = src.cityArray[i].active;
            
            if (!cityArray[i].active) continue; // 如果源城市不活跃，跳过数据拷贝
    
            cityArray[i].name = src.cityArray[i].name;
            cityArray[i].admin = src.cityArray[i].admin;
            cityArray[i].firstEdge = nullptr;
    
            EdgeNode* prev = nullptr;
            EdgeNode* cur = src.cityArray[i].firstEdge;
            while (cur) {
                EdgeNode* newEdge = new EdgeNode(
                    cur->to, cur->transport, cur->depart_time, cur->arrive_time,
                    cur->cost, cur->number, cur->duration, cur->status
                );
                if (!prev) cityArray[i].firstEdge = newEdge;
                else prev->next = newEdge;
                prev = newEdge;
                cur = cur->next;
            }
        }
    }
    
};
