/**
 * Login logic for both User and Admin forms
 */
document.addEventListener('DOMContentLoaded', () => {
    const userForm = document.getElementById('userForm');
    const adminForm = document.getElementById('adminForm');

    /**
     * 处理登录逻辑
     * @param {Event} e 事件对象
     * @param {string} expectedRole 期望的角色 ('user' 或 'admin')
     */
    const handleLogin = async (e, expectedRole) => {
        e.preventDefault();

        const form = e.target;
        const submitBtn = form.querySelector('.submit-btn');
        const btnText = submitBtn.querySelector('.btn-text');

        // 1. 提取数据
        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());

        // 2. 基础校验
        if (!data.username || !data.password) {
            alert("请输入用户名和密码");
            return;
        }

        try {
            // UI 反馈
            submitBtn.disabled = true;
            btnText.innerText = "AUTHENTICATING...";

            // 3. 发送登录请求 (后端验证账号密码)
            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    username: data.username,
                    password: data.password
                })
            });

            // 4. 处理结果
            if (response.ok) {
                const result = await response.json(); // 获取后端返回的 {token, role}

                // --- 核心控制逻辑：检查返回的角色是否与当前表单匹配 ---
                if (result.role !== expectedRole) {
                    // 如果角色不匹配，手动视为登录失败
                    alert(`身份不匹配！此入口仅限 ${expectedRole.toUpperCase()} 登录。`);
                    
                    // 即使后端生成了 token，前端也拒绝保存
                    submitBtn.disabled = false;
                    btnText.innerText = "Submit";
                    return; 
                }

                // --- 匹配成功，执行正常存储 ---
                localStorage.setItem('token', result.token);
                localStorage.setItem('username', data.username);
                localStorage.setItem('role', result.role);

                alert(`登录成功！欢迎回来, ${data.username}`);

                // --- 跳转 ---
                if (result.role === 'admin') {
                    window.location.href = '/admin_editor.html';
                } else {
                    window.location.href = './user_check.html';
                }

            } else if (response.status === 401) {
                alert("登录失败：用户名或密码错误");
            } else {
                const errText = await response.text();
                alert("系统错误: " + errText);
            }
        } catch (error) {
            console.error("Login Error:", error);
            alert("无法连接到服务器");
        } finally {
            submitBtn.disabled = false;
            btnText.innerText = "Submit";
        }
    };

    if (userForm) {
        userForm.addEventListener('submit', (e) => handleLogin(e, 'user'));
    }
    
    if (adminForm) {
        adminForm.addEventListener('submit', (e) => handleLogin(e, 'admin'));
    }
});