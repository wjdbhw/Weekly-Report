let curSlide = 1;
let numOfSlides = 0;
let animation = false;
const animSpd = 750;
let diff = 0;

// 背景图库，根据交通工具切换
const bgImages = [
    'https://s3-us-west-2.amazonaws.com/s.cdpn.io/537051/city--1-min-min.jpg',
    'https://s3-us-west-2.amazonaws.com/s.cdpn.io/537051/city--2-min-min.jpg',
    'https://s3-us-west-2.amazonaws.com/s.cdpn.io/537051/city--3-min-min.jpg',
    'https://s3-us-west-2.amazonaws.com/s.cdpn.io/537051/city--4-min-min.jpg',
    'https://s3-us-west-2.amazonaws.com/s.cdpn.io/537051/city--5-min-min.jpg'
];

async function fetchRoute() {
    const requestData = {
        from: $('#fromCity').val(),
        to: $('#toCity').val(),
        strategy: $('#strategy').val(),
        hurry_index: 0.5
    };

    try {
        const response = await fetch('http://localhost:8080/api/query/shortest_path', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(requestData)
        });
        const data = await response.json();
        
        // 假设后端返回的数据包含 total_cost, total_time 和 path 数组
        renderSlider(data);
    } catch (err) {
        alert("无法连接到后端服务器，请确保 Crow 服务已启动并配置跨域。");
        console.error(err);
    }
}

function renderSlider(data) {
    const $slider = $('.slider').empty().removeClass('animation');
    const $nav = $('.nav').empty();
    const path = data.path || []; 
    numOfSlides = path.length;
    curSlide = 1;

    if (numOfSlides === 0) {
        $slider.html('<div class="placeholder-text">未找到有效路径</div>');
        return;
    }

    // 更新汇总面板
    $('#totalTime').text(data.total_time || 'N/A');
    $('#totalCost').text('¥' + (data.total_cost || 0));
    $('#summaryPanel').fadeIn();

    path.forEach((edge, i) => {
        const index = i + 1;
        const bg = bgImages[i % bgImages.length];
        const transportChar = edge.transport ? edge.transport.charAt(0).toUpperCase() : 'T';

        const $slide = $(`
            <div data-target="${index}" class="slide slide--${index}" style="left: ${i * 100}%">
                <div class="slide__darkbg" style="background: url('${bg}') center/cover; transform: translate3d(${i * -50}%,0,0)"></div>
                <div class="slide__text-wrapper">
                    <div class="slide__letter" style="background: url('${bg}') center/cover;">${transportChar}</div>
                    <div class="slide__text">${edge.from} — ${edge.to}</div>
                    
                    <div class="edge-detail">
                        <div class="detail-box left">
                            <span>分段花费</span>
                            <strong>¥${edge.cost}</strong>
                        </div>
                        <div class="detail-box right">
                            <span>预计耗时</span>
                            <strong>${edge.duration || '未知'}</strong>
                        </div>
                    </div>
                </div>
            </div>
        `);

        $slider.append($slide);
        $nav.append(`<li data-target="${index}" class="nav__slide ${i===0?'nav-active':''}"></li>`);
    });

    initEvents();
}

function pagination(direction) {
    animation = true;
    const $slider = $('.slider');
    $slider.addClass('animation');
    
    // 计算位移
    const sliderX = (curSlide - direction) * 100;
    $slider.css('transform', `translate3d(-${sliderX}%, 0, 0)`);
    
    $slider.find('.slide__darkbg').each(function(i) {
        const bgX = (curSlide - direction) * 50 + (i * -50);
        $(this).css('transform', `translate3d(${bgX}%, 0, 0)`);
    });

    setTimeout(() => { animation = false; }, animSpd);
}

function navigateRight() {
    if (curSlide >= numOfSlides || animation) return;
    pagination(0);
    curSlide++;
    updateNav();
}

function navigateLeft() {
    if (curSlide <= 1 || animation) return;
    pagination(2);
    curSlide--;
    updateNav();
}

function updateNav() {
    $('.nav__slide').removeClass('nav-active');
    $(`.nav__slide[data-target="${curSlide}"]`).addClass('nav-active');
}

function initEvents() {
    // 侧边点击
    $(document).off('click', '.side-nav').on('click', '.side-nav', function() {
        if ($(this).data('target') === 'right') navigateRight();
        else navigateLeft();
    });

    // 滚轮控制
    $(document).off('mousewheel DOMMouseScroll').on('mousewheel DOMMouseScroll', function(e) {
        let delta = e.originalEvent.wheelDelta;
        if (delta > 0) navigateLeft(); else navigateRight();
    });

    // 键盘控制
    $(document).off('keydown').on('keydown', function(e) {
        if (e.which === 39) navigateRight();
        if (e.which === 37) navigateLeft();
    });
}