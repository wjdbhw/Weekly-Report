const CONFIG = {
    particleCount: 200000, // 减小一点点以保证双系统流畅度
    perMouse: 300,
    color: [0.9, 0.7, 0.3], // 纯正金
    size: 1.2,
    minSize: 0.1,
    spread: 2,
    explosionForce: 5,
    movementSpread: 10,
    speed: 0.0015,
    fadeSpeed: 0.1,
    far: 150,
    maxZ: 100
};
  
  const SHADER_PARTICLES = `
  struct Uniforms {
      resolution: vec2<f32>,
      pixelRatio: f32,
      time: f32,
      speed: f32,
      size: f32,
      minSize: f32,
      spread: f32,
      movementSpread: f32,
      explosionForce: f32,
      far: f32,
      fadeSpeed: f32,
      maxZ: f32
  };
  
  @group(0) @binding(0) var<uniform> u: Uniforms;
  
  struct VertexOutput {
      @builtin(position) position: vec4<f32>,
      @location(0) vProgress: f32,
      @location(1) vRandom: f32,
      @location(2) vUv: vec2<f32>,
      @location(3) vDepth: f32
  };
  
  fn easeOutQuart(x: f32) -> f32 {
      return 1.0 - pow(1.0 - x, 4.0);
  }
  
  @vertex
  fn vs_main(
      @builtin(vertex_index) v_index: u32,
      @location(0) pos: vec3<f32>,          
      @location(1) random: f32,             
      @location(2) mouse: vec4<f32>,        
      @location(3) aFront: vec2<f32>        
  ) -> VertexOutput {
      
      var out: VertexOutput;
      var progress = (u.time - mouse.z) * u.speed;
      progress = clamp(progress, 0.0, 1.0);
      
      if (mouse.x < -100.0) {
          out.position = vec4<f32>(0.0, 0.0, 0.0, 0.0);
          return out;
      }
  
      let startX = mouse.x - (u.resolution.x * 0.5);
      let startY = (u.resolution.y - mouse.y) - (u.resolution.y * 0.5);
      let startPosition = vec3<f32>(startX, startY, 0.0);
  
      let diff = clamp(mouse.w / 100.0, 0.0, 1.0);
      let cPosition = pos * 2.0 - 1.0; 
      let radian = cPosition.x * 6.283185;
      
      let totalSpread = u.spread + (u.movementSpread * diff) + (u.explosionForce * pow(progress, 0.4));
      let xySpread = vec2<f32>(cos(radian), sin(radian)) * totalSpread * cPosition.y; 
  
      var endPosition = startPosition;
      endPosition.x += xySpread.x - (aFront.x * u.far * random * mix(0.2, 1.0, diff));
      endPosition.y += xySpread.y + (aFront.y * u.far * random * mix(0.2, 1.0, diff)); 
      endPosition.z += cPosition.z * u.maxZ;
  
      let currentPosition = mix(startPosition, endPosition, easeOutQuart(progress));
  
      let camZ = 1200.0;
      let perspective = camZ / (camZ - currentPosition.z);
  
      let clipX = (currentPosition.x * perspective) / (u.resolution.x * 0.5);
      let clipY = (currentPosition.y * perspective) / (u.resolution.y * 0.5);
  
      var corners = array<vec2<f32>, 6>(
          vec2<f32>(-1.0, -1.0), vec2<f32>( 1.0, -1.0), vec2<f32>(-1.0,  1.0),
          vec2<f32>(-1.0,  1.0), vec2<f32>( 1.0, -1.0), vec2<f32>( 1.0,  1.0)
      );
      let corner = corners[v_index];
      out.vUv = corner;
  
      let finalSize = max(u.size * sin(progress * 3.14) * perspective * u.pixelRatio, u.minSize);
  
      out.position = vec4<f32>(
          clipX + (corner.x * finalSize / u.resolution.x), 
          clipY + (corner.y * finalSize / u.resolution.y), 
          0.5, 1.0
      );
  
      out.vProgress = progress;
      out.vRandom = random;
      out.vDepth = cPosition.z;
      return out;
  }
  
  @fragment
  fn fs_main(in: VertexOutput) -> @location(0) vec4<f32> {
      let len = length(in.vUv);
      if (len > 1.0) { discard; }
  
      let dt = dot(vec2<f32>(in.vProgress * in.vRandom), vec2<f32>(12.9898, 78.233));
      var twinkle = mix(0.4, 1.0, fract(sin(dt % 3.14) * 43758.5453)); 
  
      let alpha = pow(1.0 - in.vProgress, u.fadeSpeed) * twinkle * (1.0 - len) * mix(0.5, 1.0, in.vDepth);
      return vec4<f32>(vec3<f32>(${CONFIG.color.join(",")}) * twinkle, alpha);
  }
  `;
  
  class WebGPUApp {
    constructor(canvas) {
      this.canvas = canvas;
      this.mouseIndex = 0;
      this.oldPos = null;
      this.lastFx = 0;
      this.lastFy = 0;
      this.resize();
    }
  
    async init() {
      if (!navigator.gpu) {
        document.getElementById("loader").innerText = "WebGPU not supported on this browser.";
        throw new Error("WebGPU not supported");
      }
      this.adapter = await navigator.gpu.requestAdapter();
      this.device = await this.adapter.requestDevice();
      this.context = this.canvas.getContext("webgpu");
      this.format = navigator.gpu.getPreferredCanvasFormat();
  
      this.context.configure({ 
        device: this.device, 
        format: this.format, 
        alphaMode: "premultiplied" 
      });
  
      await this.setupParticles();
      this.setupInputs();
  
      window.addEventListener("resize", () => this.resize());
      const renderLoop = (t) => {
        this.render(t);
        requestAnimationFrame(renderLoop);
      };
      requestAnimationFrame(renderLoop);
      document.getElementById("loader").style.display = "none";
    }
  
    resize() {
      this.dpr = Math.min(window.devicePixelRatio, 2);
      this.width = window.innerWidth * this.dpr;
      this.height = window.innerHeight * this.dpr;
      this.canvas.width = this.width;
      this.canvas.height = this.height;
    }
  
    async setupParticles() {
      const count = CONFIG.particleCount;
      // 静态属性: [pos.x, pos.y, pos.z, random]
      const staticData = new Float32Array(count * 4);
      for (let i = 0; i < count * 4; i++) staticData[i] = Math.random();
      this.bufStatic = this.createBuffer(staticData, GPUBufferUsage.VERTEX);
  
      // 动态属性: [mouseX, mouseY, timestamp, dist, lastFx, lastFy]
      const dynamicData = new Float32Array(count * 6);
      dynamicData.fill(-1000); 
      this.bufDynamic = this.device.createBuffer({
        size: dynamicData.byteLength,
        usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST
      });
  
      this.bufUniforms = this.device.createBuffer({
        size: 128,
        usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
      });
  
      const module = this.device.createShaderModule({ code: SHADER_PARTICLES });
      this.pipeline = this.device.createRenderPipeline({
        layout: "auto",
        vertex: {
          module,
          entryPoint: "vs_main",
          buffers: [
            { arrayStride: 16, stepMode: "instance", attributes: [
              { format: "float32x3", offset: 0, shaderLocation: 0 },
              { format: "float32", offset: 12, shaderLocation: 1 }
            ]},
            { arrayStride: 24, stepMode: "instance", attributes: [
              { format: "float32x4", offset: 0, shaderLocation: 2 },
              { format: "float32x2", offset: 16, shaderLocation: 3 }
            ]}
          ]
        },
        fragment: {
          module,
          entryPoint: "fs_main",
          targets: [{
            format: this.format,
            blend: {
              color: { srcFactor: "src-alpha", dstFactor: "one", operation: "add" },
              alpha: { srcFactor: "zero", dstFactor: "one", operation: "add" }
            }
          }]
        },
        primitive: { topology: "triangle-list" }
      });
  
      this.bindGroup = this.device.createBindGroup({
        layout: this.pipeline.getBindGroupLayout(0),
        entries: [{ binding: 0, resource: { buffer: this.bufUniforms } }]
      });
    }
  
    createBuffer(data, usage) {
      const buf = this.device.createBuffer({ size: data.byteLength, usage, mappedAtCreation: true });
      new data.constructor(buf.getMappedRange()).set(data);
      buf.unmap();
      return buf;
    }
  
    setupInputs() {
      const move = (cx, cy) => this.updateTrail(cx * this.dpr, cy * this.dpr);
      window.addEventListener("pointermove", (e) => move(e.clientX, e.clientY));
      window.addEventListener("touchmove", (e) => {
          e.preventDefault();
          move(e.touches[0].clientX, e.touches[0].clientY);
      }, { passive: false });
    }
  
    updateTrail(x, y) {
      const now = performance.now();
      let dx = 0, dy = 0, dist = 0;
      if (this.oldPos) {
        dx = x - this.oldPos.x;
        dy = y - this.oldPos.y;
        dist = Math.sqrt(dx * dx + dy * dy);
      }
      
      const fx = dist > 0 ? dx / dist : this.lastFx;
      const fy = dist > 0 ? dy / dist : this.lastFy;
  
      const count = CONFIG.perMouse;
      const data = new Float32Array(count * 6);
      for (let i = 0; i < count; i++) {
        const r = i / count;
        data[i * 6] = this.oldPos ? this.oldPos.x + dx * r : x;
        data[i * 6 + 1] = this.oldPos ? this.oldPos.y + dy * r : y;
        data[i * 6 + 2] = now;
        data[i * 6 + 3] = dist;
        data[i * 6 + 4] = fx;
        data[i * 6 + 5] = fy;
      }
  
      this.device.queue.writeBuffer(this.bufDynamic, (this.mouseIndex % CONFIG.particleCount) * 24, data);
      this.mouseIndex += count;
      this.oldPos = { x, y };
      this.lastFx = fx; this.lastFy = fy;
    }
  
    render(time) {
      const encoder = this.device.createCommandEncoder();
      const pass = encoder.beginRenderPass({
        colorAttachments: [{
          view: this.context.getCurrentTexture().createView(),
          clearValue: { r: 0, g: 0, b: 0, a: 0 },
          loadOp: "clear", storeOp: "store"
        }]
      });
  
      const uni = new Float32Array([
          this.width, this.height, this.dpr, time,
          CONFIG.speed, CONFIG.size, CONFIG.minSize, CONFIG.spread,
          CONFIG.movementSpread, CONFIG.explosionForce, CONFIG.far, CONFIG.fadeSpeed, CONFIG.maxZ
      ]);
      this.device.queue.writeBuffer(this.bufUniforms, 0, uni);
  
      pass.setPipeline(this.pipeline);
      pass.setBindGroup(0, this.bindGroup);
      pass.setVertexBuffer(0, this.bufStatic);
      pass.setVertexBuffer(1, this.bufDynamic);
      pass.draw(6, CONFIG.particleCount);
      pass.end();
      this.device.queue.submit([encoder.finish()]);
    }
  }
  
  // 启动应用
  const canvas = document.getElementById("canvas");
  const app = new WebGPUApp(canvas);
  app.init().catch(err => {
    console.error(err);
  });