document.addEventListener('DOMContentLoaded', () => {
    const userForm = document.getElementById('userForm');
    const adminForm = document.getElementById('adminForm');

    // 基础前端防护与提交逻辑
    async function handleRegister(e, type) {
        e.preventDefault();
        
        const form = e.target;
        const submitBtn = form.querySelector('.submit-btn');
        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());

        // --- 1. 基础前端防护 ---
        
        // 防止空输入 (HTML5 required 虽有，但 JS 校验更稳)
        if (!data.username.trim() || !data.password.trim()) {
            alert("用户名或密码不能为空");
            return;
        }

        // 长度限制
        if (data.username.length < 3 || data.username.length > 20) {
            alert("用户名长度需在 3-20 位之间");
            return;
        }

        // 简单字符过滤 (防止基础的注入攻击尝试)
        const illegalChars = /['"\\;=]/;
        if (illegalChars.test(data.username) || illegalChars.test(data.password)) {
            alert("输入包含非法字符");
            return;
        }

        // --- 2. 提交逻辑 ---
        
        // 禁用按钮防止重复点击
        submitBtn.disabled = true;
        const originalBtnText = submitBtn.querySelector('.btn-text').innerText;
        submitBtn.querySelector('.btn-text').innerText = "Processing...";

        try {
            const response = await fetch('/api/auth/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });

            const resultText = await response.text();

            if (response.ok) {
                alert("注册成功！");
                form.reset();
            } else if (response.status === 409) {
                alert("错误：用户名已存在");
            } else if (response.status === 400) {
                alert("错误：输入信息有误");
            } else {
                alert("服务器验证未通过: " + resultText);
            }
        } catch (error) {
            console.error("Network Error:", error);
            alert("网络连接失败，请检查后端服务是否运行");
        } finally {
            // 恢复按钮
            submitBtn.disabled = false;
            submitBtn.querySelector('.btn-text').innerText = originalBtnText;
        }
    }

    // 绑定事件
    userForm.addEventListener('submit', (e) => handleRegister(e, 'user'));
    adminForm.addEventListener('submit', (e) => handleRegister(e, 'admin'));
});